<?php $__env->startSection('content'); ?>
    <style>
        .product-description {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
    </style>
    <main class="" style="background: #fcf8ee75;">
        <section class="shop-banner-section">
            <div class="container-fluid px-4">
                <div class="shop-banner">
                    <div>
                        <h1 class="sh-head">Products</h1>
                        <p class="sh-para"><a href="<?php echo e(route('index')); ?>" class="text-decoration-none">Home</a> / <a
                                href="<?php echo e(route('web.products.index')); ?>" class="text-decoration-none">Products</a>
                            / <?php echo e($product->name); ?></p>
                    </div>
                </div>
            </div>
        </section>

        <div class="sh-space padd-small padd-small-2">
            <div class="container-fluid px-4">
                <div class="row row-gap-3">
                    <div class="col-xl-2 col-12 p-0 column-sliders position-relative">

                        <div class="side-images-wrap">
                            <div class="side-image" style="border:2px solid #4f7eff">
                                <img src="<?php echo e($product->getFirstMediaUrl('featured_image')); ?>" alt="Product Image"
                                    class="gallery-img-item">
                            </div>
                            <?php $__empty_1 = true; $__currentLoopData = $product->getMediaCollectionUrl('multiple_images'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="side-image" style="border:2px solid #4f7eff">
                                    <img src="<?php echo e($image); ?>" alt="Product Image" class="gallery-img-item">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <?php endif; ?>

                            
                        </div>
                        <div class="slider-btns-2">
                            <button class="previous-btn-2"><i class="fa-solid fa-arrow-left"></i></button>
                            <button class="next-btn-2"><i class="fa-solid fa-arrow-right"></i></button>
                        </div>
                    </div>
                    <div class="col-xl-5 col-lg-6 col-12">
                        <div class="product-page">
                            <div class="product-images">
                                <img src="<?php echo e($product->getFirstMediaUrl('featured_image')); ?>" alt="Product Image"
                                    class="img-change">
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-5 col-lg-6 col-12">
                        <div class="product-details">
                            <h1 class="product-title mb-3"><?php echo e($product->name); ?></h1>
                            <p class="product-description"><?php echo $product->description; ?></p>
                            <p class="product-price" id="base-price">$<?php echo e($product->price); ?></p>
                            <?php
                                // Group variants by attribute name
                                $counter = 1;
                                $storedData = ['attribute_id' => null]; // Array use kiya reference maintain karne ke liye

                                $groupedVariants = $product->variants
                                    ->flatMap(function ($variant) use (&$counter, &$storedData) {
                                        return $variant->attributeValues->map(function ($attributeValue) use (
                                            &$counter,
                                            &$storedData,
                                        ) {
                                            if ($counter == 1) {
                                                $storedData['attribute_id'] = $attributeValue->attribute_id; // Properly store attribute_id
                                            }

                                            $counter++; // Counter increment karna
                                            return [
                                                'attribute_name' => $attributeValue->attribute->name,
                                                'attribute_value' => $attributeValue->value,
                                                'attribute_value_id' => $attributeValue->id,
                                            ];
                                        });
                                    })
                                    ->groupBy('attribute_name');

                            ?>
                            <form id="variantForm">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" id="">
                                
                                <?php $__currentLoopData = $groupedVariants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributeName => $attributeValues): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="attributes[]" value="<?php echo e($attributeName); ?>" id="">
                                    <p class="product-price"><?php echo e($attributeName); ?></p>
                                    <div class="storage-btn-area">
                                        <?php $__currentLoopData = $attributeValues->unique('attribute_value'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $radioId = $attributeName . '-' . $value['attribute_value_id'];
                                            ?>
                                            <input type="radio" id="<?php echo e($radioId); ?>" class="custom-radios"
                                                name="attribute_values[]-<?php echo e($attributeName); ?>"
                                                value="<?php echo e($value['attribute_value_id']); ?>">
                                            <label for="<?php echo e($radioId); ?>"><?php echo e($value['attribute_value']); ?></label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </form>


                            <p><span id="priceDisplay" class="text-danger"></span></p>
                            <div class="buttons-group">
                                <div class="quantity-selection counter-area">
                                    <button class="btn  decrement decrement-2">-</button>
                                    <input type="text" name="qty" readonly value="1" class="qtyValue">
                                    <button class="btn  increment increment-2">+</button>
                                </div>
                                <button href="<?php echo e(route('cart-page')); ?>" class="add-to-cart-btn text-decoration-none"
                                    id="add-to-cart">Add To
                                    Cart</button>
                            </div>
                            <div class="add-to-cart d-flex flex-column justify-content-center  gap-3 mt-3">
                                <?php if($product->is_premium): ?>
                                    <button class="add-cart-btn offer-btn">Make an offer</button>
                                <?php endif; ?>
                                <button href="<?php echo e(route('checkout')); ?>" class="add-cart-btn buy-outline" id="buy-now">Buy
                                    Now</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <section class="informative-section-product">
                <div class="container-fluid">
                    <div class="row ">
                        <div class="col-xl-8 col-12">
                            <div class="content-box-products">
                                <div class="content-header-products">
                                    <button class="product-tab-btn active" data-value="description">Description</button>
                                    <button class="product-tab-btn" data-value="additional-information">Additional
                                        Information
                                    </button>
                                </div>
                                <div class="text-sec-pro">
                                    <div id="description">
                                        <p class="des-text-area"><?php echo e($product->long_description); ?>

                                    </div>
                                    <div id="additional-information" style="display: none">
                                        <p class="des-text-area">hy,Cras aliquam ultricies ante, eu sollicitudin nulla
                                            mattis
                                            et.
                                            Proin
                                            non
                                            sapien commodo,
                                            maximus libero eu, dictum massa. Interdum et malesuada fames ac ante ipsum
                                            primis in
                                            faucibus. Mauris posuere sem a tellus posuere, non aliquet lacus faucibus.
                                            Aliquam
                                            sodales
                                            vestibulum sollicitudin. Proin ullamcorper gravida mi, sit amet pharetra justo
                                            rhoncus
                                            vitae. Suspendisse volutpat tempor massa id efficitur. Ut fermentum rhoncus
                                            hendrerit.
                                            Vestibulum maximus tempus turpis, vel aliquet odio euismod at. Sed sed justo non
                                            mauris
                                            cursus varius in a leo. Proin iaculi placerat placerat.icitudin. Proin
                                            ullamcorper
                                            gravida
                                            mi, sit amet pharetra justo rhoncus vitae.</p>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4  col-12 col-remove">
                            <img src="<?php echo e(asset('assets/web/images/mobile-phone-img.png')); ?>"
                                class="img-fluid mobile-side-img" alt="">
                        </div>
                    </div>
                </div>
            </section>
            <section class="featured-products">
                <div class="container-fluid">
                    <div class="row mt-5">
                        <div class="col-12">
                            <div class="text-center">
                                <span class="exc-products">Top Rated</span>
                                <h2 class="main-sec-heading my-4">
                                    Related&nbsp;Products
                                </h2>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <?php $__empty_1 = true; $__currentLoopData = $relatedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $relatedProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-xxl-3 col-lg-4 col-md-6 col-sm-6 col-12 mb-3">
                                <div class="product-card sh-prod-card">
                                    <div class="products-img sh-prod">
                                        <div class="d-flex justify-content-between align-items-center mb-4">
                                            <p class="top-img"><?php echo e($relatedProduct->category->name); ?></p>
                                            <button class="btn heart-save-btn p-0 wishlist-btn"
                                                data-slug="<?php echo e($relatedProduct->slug); ?>">
                                                <i class=" <?php echo e(auth()?->user()?->hasWishlisted($relatedProduct->id) ? 'fa-solid' : 'fa-regular'); ?> fa-heart"
                                                    data-slug="icon-<?php echo e($relatedProduct->slug); ?>"
                                                    style="color: rgb(255, 114, 114)"></i>
                                            </button>
                                        </div>
                                        <img src="<?php echo e($relatedProduct->getFirstMediaUrl('featured_image')); ?>"
                                            class="img-fluid" alt="">
                                    </div>
                                    <div class="product-content">
                                        <h2 class="card-main-heading mb-4"><?php echo e($relatedProduct->name); ?></h2>
                                        <div class="rating-stars">
                                            <?php for($i = 0; $i < 5; $i++): ?>
                                                <?php if($relatedProduct['id'] > $i): ?>
                                                    <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>"
                                                        alt="Gold Star">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('assets/web/images/silver-star.png')); ?>"
                                                        alt="Silver Star">
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                        </div>
                                        <div class="bottom-price-area mb-3">
                                            <p class="price-products">$<?php echo e($relatedProduct->price); ?>

                                            </p>

                                            <a href="<?php echo e(route('web.products.show', $relatedProduct->slug)); ?>"
                                                class="bid-btn text-decoration-none">Buy
                                                Now</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col-12">
                                <h2 class="text-center">No Related Products Found</h2>
                            </div>
                        <?php endif; ?>


                    </div>
                </div>
            </section>
        </div>
        <?php if (isset($component)) { $__componentOriginalf53df0eb2e0eda3be514418670264723 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf53df0eb2e0eda3be514418670264723 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.slide-blog','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('slide-blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf53df0eb2e0eda3be514418670264723)): ?>
<?php $attributes = $__attributesOriginalf53df0eb2e0eda3be514418670264723; ?>
<?php unset($__attributesOriginalf53df0eb2e0eda3be514418670264723); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf53df0eb2e0eda3be514418670264723)): ?>
<?php $component = $__componentOriginalf53df0eb2e0eda3be514418670264723; ?>
<?php unset($__componentOriginalf53df0eb2e0eda3be514418670264723); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal73a4fc63cac428a7be4f481d37ff424d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73a4fc63cac428a7be4f481d37ff424d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.offer-modal','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('offer-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73a4fc63cac428a7be4f481d37ff424d)): ?>
<?php $attributes = $__attributesOriginal73a4fc63cac428a7be4f481d37ff424d; ?>
<?php unset($__attributesOriginal73a4fc63cac428a7be4f481d37ff424d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73a4fc63cac428a7be4f481d37ff424d)): ?>
<?php $component = $__componentOriginal73a4fc63cac428a7be4f481d37ff424d; ?>
<?php unset($__componentOriginal73a4fc63cac428a7be4f481d37ff424d); ?>
<?php endif; ?>
    </main>
    <script>
        let incBtns2 = document.querySelector('.increment-2');
        let decBtns2 = document.querySelector('.decrement-2');

        incBtns2.addEventListener('click', () => {
            let inputs = document.querySelector('.counter-area').querySelector('input');
            inputs.value++;
        })

        decBtns2.addEventListener('click', () => {
            let inputs = document.querySelector('.counter-area').querySelector('input');
            if (inputs.value > 1) {
                inputs.value--;
            }
        })


        let img = document.querySelectorAll('.side-image');
        img.forEach(item => {
            item.addEventListener('click', () => {

                img.forEach(img => img.style.border = "1px solid gray")
                const imgTag = item.querySelector("img");
                console.log(imgTag);

                document.querySelector('.img-change').src = imgTag.src;
                item.style.border = "2px solid #4f7eff";
            })
        })

        const tabMethod = (e, btn) => {
            const valueId = e.target.getAttribute('data-value');
            const valueId2 = btn.getAttribute('data-value');
            document.getElementById(valueId).style.display = "block";
            e.target.classList.add('active');
            btn.classList.remove('active');
            document.getElementById(valueId2).style.display = "none";
        }
        const btnsTab = document.querySelectorAll('.product-tab-btn');
        btnsTab[0].addEventListener('click', (e) => {
            tabMethod(e, btnsTab[1])
        })
        btnsTab[1].addEventListener('click', (e) => {
            tabMethod(e, btnsTab[0])
        })
    </script>

    <script>
        document.querySelectorAll('#variantForm .custom-radios').forEach(select => {
            select.addEventListener('change', () => {
                const form = document.getElementById('variantForm');
                const formData = new FormData(form);

                var basePriceDiv = document.getElementById('base-price');
                var addToCartBtn = document.getElementById('add-to-cart');
                var buyNowBtn = document.getElementById('buy-now');
                var priceDisplayDiv = document.getElementById('priceDisplay');

                fetch('/get-variant-price', {
                        method: 'POST',
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                        },
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        console.log(data);

                        let basePrice = parseFloat(
                            <?php echo json_encode($product->price, 15, 512) ?>
                        ); // Laravel se price fetch karna sahi position pe
                        let newPrice = data.price ? parseFloat(data.price) : 0;

                        if (data.price === null) {
                            priceDisplayDiv.textContent = "Selected Combination is not available";
                            addToCartBtn.disabled = true;
                            buyNowBtn.disabled = true;
                            basePriceDiv.textContent = "$" + basePrice; // Default price dikhayein
                        } else if (data.quantity === 0) {
                            priceDisplayDiv.textContent = "Selected Combination is out of stock";
                            addToCartBtn.disabled = true;
                            buyNowBtn.disabled = true;
                        } else {
                            let finalPrice = basePrice + newPrice; // Naya price calculate karein
                            priceDisplayDiv.textContent = ""; // Extra text clear karein
                            basePriceDiv.textContent = "$" + finalPrice.toFixed(
                                2); // Price ko 2 decimal points tak rakhein
                            addToCartBtn.disabled = false;
                            buyNowBtn.disabled = false;
                        }
                    })
                    .catch(error => console.log('Error:', error));
            });
        });

        function updateButtonIcons() {
            let previousBtn = document.querySelector(".previous-btn-2 i");
            let nextBtn = document.querySelector(".next-btn-2 i");

            let isMobile = screen.width < 1200;


            previousBtn.className = `fa-solid ${isMobile ? "fa-arrow-left" : "fa-arrow-up"}`;
            nextBtn.className = `fa-solid ${isMobile ? "fa-arrow-right" : "fa-arrow-down"}`;
        }

        // Page load pe chalayega
        updateButtonIcons();

        // Window resize hone pe bhi chalayega
        window.addEventListener("resize", updateButtonIcons);
    </script>

    <script>
        $(document).ready(function() {
            $('#add-to-cart').on('click', function() {
                let product_id = $('input[name="product_id"]').val();
                let quantity = $('input[name="qty"]').val();
                let selectedAttributes = $('input[name^="attribute_values"]:checked');

                let attributeValues = [];
                selectedAttributes.each(function() {
                    attributeValues.push($(this).val());
                });

                if (attributeValues.length === 0) {
                    Swal.fire({
                        icon: 'warning',
                        title: 'Oops...',
                        text: 'Please select a variant!',
                    });
                    return;
                }
                console.log('Product ID:', product_id, 'quantity : ', quantity, 'attributeValues : ',
                    attributeValues);

                // Pehle variant price aur stock check karenge
                $.ajax({
                    url: '/get-variant-price',
                    type: 'POST',
                    data: {
                        _token: $('input[name="_token"]').val(),
                        product_id: product_id,
                        attribute_values: attributeValues
                    },
                    success: function(data) {
                        if (!data.price) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Not Available',
                                text: 'Selected combination is not available!',
                            });
                            return;
                        }
                        console.log(data)
                        // Ab cart me add karenge
                        $.ajax({
                            url: "<?php echo e(route('web.cart.add')); ?>",
                            type: 'POST',
                            data: {
                                _token: $('input[name="_token"]').val(),
                                product_id: product_id,
                                variant_id: data.variant_id,
                                quantity: quantity,
                                attribute_values: attributeValues
                            },
                            success: function(cartData) {
                                console.log('success :', cartData);

                                if (cartData.success) {
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Added!',
                                        text: 'Item added to cart successfully!',
                                        showConfirmButton: false,
                                        timer: 2000
                                    });
                                    $('.cart-count').text(cartData.cart
                                    .total_items);
                                    $('.cart-price').text('$' + cartData.cart
                                    .total);
                                }

                            },
                            error: function(error) {
                                console.log('Error:', error);

                                Swal.fire({
                                    icon: 'warning',
                                    title: 'Sorrry.!',
                                    text: error.responseJSON.message,
                                });
                            }
                        });
                    },
                    error: function(error) {
                        Swal.fire({
                            icon: 'warning',
                            title: 'Opps...!',
                            text: error.responseJSON.message,
                        });
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>




















<?php echo $__env->make('layouts.web.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Anjan Parmar\resources\views/screens/web/products/show.blade.php ENDPATH**/ ?>