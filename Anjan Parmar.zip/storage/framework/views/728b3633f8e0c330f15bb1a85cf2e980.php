<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'headTitle' => $headTitle ?? 'Our Blogs',
    'subTitle' => $subTitle ?? 'Latest News & Update',
    'blogs' => $blogs ?? null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'headTitle' => $headTitle ?? 'Our Blogs',
    'subTitle' => $subTitle ?? 'Latest News & Update',
    'blogs' => $blogs ?? null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<section class="blog-section mx-3">
    <div class="container-fluid p-0">
        <div class="row justify-content-center">
            <div class="col-lg-10 col-md-12">
                <div class="row align-items-center text-center justify-content-between mb-5">
                    <div class="col-12">
                        <div class="blog-hd-area" style="border-left: none">
                            <span class="exc-products"><?php echo e($headTitle); ?></span>
                            <h1 class="main-sec-heading mt-5">Latest News & Update</h1>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <hr class="blog-hr">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-4 col-md-6 col-sm-6 col-12 p-0">
                    <div class="blog-card">
                        <div class="blog-img-area">
                            <img class="img-fluid blog-img" src="<?php echo e($blog->getFirstMediaUrl('blog_image')); ?>"
                                alt="">
                            <span class="img-banner"><?php echo e($blog->created_at); ?></span>
                        </div>
                        <div class="blog-text-area">
                            <h3 class="card-main-heading"><?php echo e($blog->name); ?></h3>
                            <p class="para gray"><?php echo e(\Str::limit($blog->short_description, 50, '...')); ?></p>
                            <a href="<?php echo e(route('web.blogs.show', $blog->slug)); ?>" class="link-btn">Read More</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <?php endif; ?>
        </div>
    </div>








</section>
<?php /**PATH C:\xampp\htdocs\Anjan Parmar\resources\views/components/our-blog.blade.php ENDPATH**/ ?>