<?php
    $tabContent = [
        ['btnText' => 'All Products', 'imgUrl' => 'assets/web/images/icon-1.png'],
        ['btnText' => 'Gadgets', 'imgUrl' => 'assets/web/images/tv-icon.png'],
        ['btnText' => "Clothing's", 'imgUrl' => 'assets/web/images/fashion.png'],
        ['btnText' => 'Appliances', 'imgUrl' => 'assets/web/images/portfolio.png'],
    ];
?>

<?php $__env->startSection('content'); ?>
    <main>
        
        <section class="banner mx-4">
            <div class="container-fluid px-5 content-area">
                <div class="row">
                    <div class="col-12">
                        <div>
                            <span class="bnner-btn">Welcome To The Seal Offer</span>
                            <h2 class="main-bnner-heading mt-5">
                                The New Year <br />
                                <span class="collection-text">Collection</span>
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php if (isset($component)) { $__componentOriginalb3f107c9438ddb8979c41bf4a6c8f473 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb3f107c9438ddb8979c41bf4a6c8f473 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.offers-cards','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('offers-cards'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb3f107c9438ddb8979c41bf4a6c8f473)): ?>
<?php $attributes = $__attributesOriginalb3f107c9438ddb8979c41bf4a6c8f473; ?>
<?php unset($__attributesOriginalb3f107c9438ddb8979c41bf4a6c8f473); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb3f107c9438ddb8979c41bf4a6c8f473)): ?>
<?php $component = $__componentOriginalb3f107c9438ddb8979c41bf4a6c8f473; ?>
<?php unset($__componentOriginalb3f107c9438ddb8979c41bf4a6c8f473); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginal135d320eff19cc619c01e775aa901454 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal135d320eff19cc619c01e775aa901454 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.products-sliders','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('products-sliders'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal135d320eff19cc619c01e775aa901454)): ?>
<?php $attributes = $__attributesOriginal135d320eff19cc619c01e775aa901454; ?>
<?php unset($__attributesOriginal135d320eff19cc619c01e775aa901454); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal135d320eff19cc619c01e775aa901454)): ?>
<?php $component = $__componentOriginal135d320eff19cc619c01e775aa901454; ?>
<?php unset($__componentOriginal135d320eff19cc619c01e775aa901454); ?>
<?php endif; ?>

        <section class="products-details mb-5">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="product-header-area">
                            <span class="exc-products">Exclusive Products</span>
                            <div class="header-products my-5">
                                <h1 class="main-sec-heading">our Premium products</h1>
                                <div class="tabs-area">
                                    <?php $__currentLoopData = $tabContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if (isset($component)) { $__componentOriginal71c4820469fce052db6c23b0c0f271bd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal71c4820469fce052db6c23b0c0f271bd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customButton','data' => ['dataValue' => $content['btnText'],'active' => ''.e($index === 0 ? 'tab-active' : '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('customButton'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['dataValue' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content['btnText']),'active' => ''.e($index === 0 ? 'tab-active' : '').'']); ?>
                                            <span class="icon-tab">
                                                <img src="<?php echo e(asset($content['imgUrl'])); ?>" alt="">
                                            </span>
                                            <span><?php echo e($content['btnText']); ?></span>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal71c4820469fce052db6c23b0c0f271bd)): ?>
<?php $attributes = $__attributesOriginal71c4820469fce052db6c23b0c0f271bd; ?>
<?php unset($__attributesOriginal71c4820469fce052db6c23b0c0f271bd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c4820469fce052db6c23b0c0f271bd)): ?>
<?php $component = $__componentOriginal71c4820469fce052db6c23b0c0f271bd; ?>
<?php unset($__componentOriginal71c4820469fce052db6c23b0c0f271bd); ?>
<?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="sliders">
                        <?php $__currentLoopData = $products1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product-card">
                                <div class="products-img">
                                    <div class="d-flex justify-content-between align-items-center mb-4">
                                        <p class="top-img"><?php echo e($productItem->category->name); ?></p>
                                        <button class="btn heart-save-btn p-0 wishlist-btn"
                                            data-slug="<?php echo e($productItem->slug); ?>">
                                            <i class=" <?php echo e(auth()?->user()?->hasWishlisted($productItem->id) ? 'fa-solid' : 'fa-regular'); ?> fa-heart"
                                                data-slug="icon-<?php echo e($productItem->slug); ?>"
                                                style="color: rgb(255, 114, 114)"></i>
                                        </button>
                                    </div>
                                    <img src="<?php echo e($productItem->getFirstMediaUrl('featured_image')); ?>" class="img-fluid"
                                        alt="">
                                </div>
                                <div class="product-content">

                                    <h2 class="card-main-heading mb-4"><?php echo e($productItem->description); ?></h2>
                                    <div class="rating-stars mb-4">
                                        <?php for($i = 0; $i < 5; $i++): ?>
                                            <?php if($productItem->id > $i): ?>
                                                <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="Gold Star">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('assets/web/images/silver-star.png')); ?>"
                                                    alt="Silver Star">
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </div>
                                    <div class="bottom-price-area mb-3">
                                        <p class="price-products">$<?php echo e($productItem->getMinPrice()); ?>

                                            -
                                            $<?php echo e($productItem->getMaxPrice()); ?>

                                        </p>

                                    </div>
                                    <div class="btn-products-now">
                                        <a href="<?php echo e(route('web.products.show', $productItem->slug)); ?>"
                                            class="bid-btn offer-btn">Make an Offer</a>
                                        <a href="<?php echo e(route('web.products.show', $productItem->slug)); ?>"
                                            class="bid-btn bid-btn-2 text-decoration-none">Buy Now</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="sales-slider">
                        <div class="sale-card">
                            <label for="sales-1" class="sale-label">
                                <span>Exclusive Clothings Discounts</span>
                                <input type="radio" disabled class="sale-input" id="sales-1" name="sales" checked>
                            </label>
                        </div>
                        <div class="sale-card">
                            <label for="sales-2" class="sale-label">
                                <span>Clearance Sales Upto 50% Off</span>
                                <input type="radio" disabled class="sale-input" id="sales-2" name="sales">
                            </label>
                        </div>
                        <div class="sale-card">
                            <label for="sales-3" class="sale-label">
                                <span>Top Tech Deals Up to 25% Off</span>
                                <input type="radio" disabled class="sale-input" id="sales-3" name="sales">
                            </label>
                        </div>
                        <div class="sale-card">
                            <label for="sales-4" class="sale-label">
                                <span>Best Deals of the Week $10 Cashback</span>
                                <input type="radio" disabled class="sale-input" id="sales-4" name="sales">
                            </label>
                        </div>
                        <div class="sale-card">
                            <label for="sales-4" class="sale-label">
                                <span>Best Deals of the Week $10 Cashback</span>
                                <input type="radio" disabled class="sale-input" id="sales-4" name="sales">
                            </label>
                        </div>
                    </div>

                    <div class="sliders">
                        <?php $__currentLoopData = $products2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product-card">
                                <div class="products-img">
                                    <div class="d-flex justify-content-between align-items-center mb-4">
                                        <p class="top-img"><?php echo e($productItem->category->name); ?></p>
                                        <button class="btn heart-save-btn p-0 wishlist-btn"
                                            data-slug="<?php echo e($productItem->slug); ?>">
                                            <i class=" <?php echo e(auth()?->user()?->hasWishlisted($productItem->id) ? 'fa-solid' : 'fa-regular'); ?> fa-heart"
                                                data-slug="icon-<?php echo e($productItem->slug); ?>"
                                                style="color: rgb(255, 114, 114)"></i>
                                        </button>
                                    </div>
                                    <img src="<?php echo e($productItem->getFirstMediaUrl('featured_image')); ?>" class="img-fluid"
                                        alt="">
                                </div>
                                <div class="product-content">

                                    <h2 class="card-main-heading my-4"><?php echo e($productItem->description); ?></h2>
                                    <div class="rating-stars mb-4">
                                        <?php for($i = 0; $i < 5; $i++): ?>
                                            <?php if($productItem->id > $i): ?>
                                                <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>"
                                                    alt="Gold Star">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('assets/web/images/silver-star.png')); ?>"
                                                    alt="Silver Star">
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </div>
                                    <div class="bottom-price-area mb-3">
                                        <p class="price-products">$<?php echo e($productItem->getMinPrice()); ?>

                                            -
                                            $<?php echo e($productItem->getMaxPrice()); ?>

                                        </p>
                                    </div>
                                    <div class="btn-products-now">
                                        <a href="<?php echo e(route('web.products.show', $productItem->slug)); ?>"
                                            class="bid-btn offer-btn" data-product="<?php echo e($productItem); ?>">Make an
                                            Offer</a>
                                        <a href="<?php echo e(route('web.products.show', $productItem->slug)); ?>"
                                            class="bid-btn bid-btn-2 text-decoration-none">Buy Now</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            


        </section>


        <section class="products-details">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        <div class="product-header-area">
                            <span class="exc-products">Trending Products</span>
                            <div class="header-products my-5">
                                <h1 class="main-sec-heading">Top Rated products</h1>
                                <div class="tabs-area">
                                    <?php $__currentLoopData = $tabContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if (isset($component)) { $__componentOriginal71c4820469fce052db6c23b0c0f271bd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal71c4820469fce052db6c23b0c0f271bd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.customButton','data' => ['dataValue' => $content['btnText'],'active' => ''.e($index === 0 ? 'tab-active' : '').'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('customButton'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['dataValue' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($content['btnText']),'active' => ''.e($index === 0 ? 'tab-active' : '').'']); ?>
                                            <span class="icon-tab">
                                                <img src="<?php echo e(asset($content['imgUrl'])); ?>" alt="">
                                            </span>
                                            <span><?php echo e($content['btnText']); ?></span>
                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal71c4820469fce052db6c23b0c0f271bd)): ?>
<?php $attributes = $__attributesOriginal71c4820469fce052db6c23b0c0f271bd; ?>
<?php unset($__attributesOriginal71c4820469fce052db6c23b0c0f271bd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c4820469fce052db6c23b0c0f271bd)): ?>
<?php $component = $__componentOriginal71c4820469fce052db6c23b0c0f271bd; ?>
<?php unset($__componentOriginal71c4820469fce052db6c23b0c0f271bd); ?>
<?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="sliders">
                        <?php $__currentLoopData = $related1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product-card">
                                <div class="products-img">
                                    <div class="d-flex justify-content-between align-items-center mb-4">
                                        <p class="top-img"><?php echo e($productItem->category->name); ?></p>
                                        <button class="btn heart-save-btn p-0 wishlist-btn"
                                            data-slug="<?php echo e($productItem->slug); ?>">
                                            <i class=" <?php echo e(auth()?->user()?->hasWishlisted($productItem->id) ? 'fa-solid' : 'fa-regular'); ?> fa-heart"
                                                data-slug="icon-<?php echo e($productItem->slug); ?>"
                                                style="color: rgb(255, 114, 114)"></i>
                                        </button>
                                    </div>
                                    <img src="<?php echo e($productItem->getFirstMediaUrl('featured_image')); ?>" class="img-fluid"
                                        alt="">
                                </div>
                                <div class="product-content">

                                    <h2 class="card-main-heading mb-4"><?php echo e($productItem->description); ?></h2>
                                    <div class="rating-stars mb-3">
                                        <?php for($i = 0; $i < 5; $i++): ?>
                                            <?php if($productItem->id > $i): ?>
                                                <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>"
                                                    alt="Gold Star">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('assets/web/images/silver-star.png')); ?>"
                                                    alt="Silver Star">
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </div>
                                    <div class="bottom-price-area">
                                        <p class="price-products">$<?php echo e($productItem->price); ?>

                                        </p>
                                        <a href="<?php echo e(route('web.products.show', $productItem->slug)); ?>"
                                            class="bid-btn text-decoration-none">Buy Now</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="sales-slider">
                        <div class="sale-card">
                            <label for="sales-1" class="sale-label">
                                <span>Exclusive Clothings Discounts</span>
                                <input type="radio" disabled class="sale-input" id="sales-1" name="sales" checked>
                            </label>
                        </div>
                        <div class="sale-card">
                            <label for="sales-2" class="sale-label">
                                <span>Clearance Sales Upto 50% Off</span>
                                <input type="radio" disabled class="sale-input" id="sales-2" name="sales">
                            </label>
                        </div>
                        <div class="sale-card">
                            <label for="sales-3" class="sale-label">
                                <span>Top Tech Deals Up to 25% Off</span>
                                <input type="radio" disabled class="sale-input" id="sales-3" name="sales">
                            </label>
                        </div>
                        <div class="sale-card">
                            <label for="sales-4" class="sale-label">
                                <span>Best Deals of the Week $10 Cashback</span>
                                <input type="radio" disabled class="sale-input" id="sales-4" name="sales">
                            </label>
                        </div>
                        <div class="sale-card">
                            <label for="sales-4" class="sale-label">
                                <span>Best Deals of the Week $10 Cashback</span>
                                <input type="radio" disabled class="sale-input" id="sales-4" name="sales">
                            </label>
                        </div>
                    </div>

                    <div class="sliders">
                        <?php $__currentLoopData = $related2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="product-card">
                                <div class="products-img">
                                    <div class="d-flex justify-content-between align-items-center mb-4">
                                        <p class="top-img"><?php echo e($productItem->category->name); ?></p>
                                        <button class="btn heart-save-btn p-0 wishlist-btn"
                                            data-slug="<?php echo e($productItem->slug); ?>">
                                            <i class=" <?php echo e(auth()?->user()?->hasWishlisted($productItem->id) ? 'fa-solid' : 'fa-regular'); ?> fa-heart"
                                                data-slug="icon-<?php echo e($productItem->slug); ?>"
                                                style="color: rgb(255, 114, 114)"></i>
                                        </button>
                                    </div>
                                    <img src="<?php echo e($productItem->getFirstMediaUrl('featured_image')); ?>" class="img-fluid"
                                        alt="">
                                </div>
                                <div class="product-content">

                                    <h2 class="card-main-heading mb-4"><?php echo e($productItem->description); ?></h2>
                                    <div class="rating-stars mb-3">
                                        <?php for($i = 0; $i < 5; $i++): ?>
                                            <?php if($productItem->id > $i): ?>
                                                <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>"
                                                    alt="Gold Star">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('assets/web/images/silver-star.png')); ?>"
                                                    alt="Silver Star">
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </div>
                                    <div class="bottom-price-area">
                                        <p class="price-products">$<?php echo e($productItem->price); ?>

                                        </p>
                                        <a href="<?php echo e(route('web.products.show', $productItem->slug)); ?>"
                                            class="bid-btn text-decoration-none">Buy Now</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

        </section>


        <section>
            <div class="container-fluid px-3">
                <div class="sales-timer">
                    <h2 class="bg-heading">Black Friday Sale</h2>
                    <div class="row align-items-center justify-content-between">
                        <div class="col-xl-6 col-xxl-5  col-12">
                            <div class="main-heading-timer">
                                <h3 class="main-sec-heading time-offer">Time-Limited Offer</h3>
                                <p class="para mt-3">Sed felis eget velit aliquet sagittis id consectetur purus. Orci
                                    sagittis eu <br> volutpat
                                    malesuada nunc vel risus odio facilisis mauris sit amet massa.</p>
                            </div>
                        </div>
                        <div class="col-xl-6 col-xxl-7  col-12">
                            <div class="countdown">
                                <div class="time-box">
                                    <span id="days" class="number">0</span>
                                    <span class="label">Days</span>
                                </div>
                                <div class="separator">
                                    <span class="separate-block"></span>
                                    <span class="separate-block"></span>
                                </div>
                                <div class="time-box">
                                    <span id="hours" class="number">0</span>
                                    <span class="label">Hrs</span>
                                </div>
                                <div class="separator">
                                    <span class="separate-block"></span>
                                    <span class="separate-block"></span>
                                </div>
                                <div class="time-box">
                                    <span id="minutes" class="number">0</span>
                                    <span class="label">Mins</span>
                                </div>
                                <div class="separator">
                                    <span class="separate-block"></span>
                                    <span class="separate-block"></span>
                                </div>
                                <div class="time-box">
                                    <span id="seconds" class="number">0</span>
                                    <span class="label">Secs</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>


        <section>
            <div class="container-fluid px-3">
                <div class="slider-wrapper-area store-sec">
                    <div class="multi-system">
                        <div class="multi-area">
                            
                            
                            <div class="multi-content  multi-content-areas">
                                <span class="exc-products">Top - Deals</span>
                                <h3 class="sys-hd">A Glimpse Inside  </h3>
                                <h3 class="sys-hd-2">Checkout Experience
                                </h3>
                                <p class="para">Ullamcorper sit amet risus nullam eget felis eget nunc. Sed lectus <br />
                                    vestibulum mattis ullamcorper velit sed ullamcorper morbi.</p>
                                <a href="<?php echo e(route('web.stores.index')); ?>" class="anchor-btn">View All Stores</a>
                            </div>
                        </div>
                        <div class="multi-area multi-area-2">
                            
                            <div class="multi-content  multi-content-areas">
                                <span class="exc-products">Premium - Choice</span>
                                <h3 class="sys-hd">Step Into Our Store </h3>
                                <h3 class="sys-hd-2">Seasonal Specials</h3>
                                <p class="para">Ullamcorper sit amet risus nullam eget felis eget nunc. Sed lectus <br />
                                    vestibulum mattis ullamcorper velit sed ullamcorper morbi.</p>
                                <a href="<?php echo e(route('web.stores.index')); ?>" class="anchor-btn">View All Stores</a>
                            </div>
                        </div>

                    </div>
                    <div class="slider-btns">
                        <button class="prev-arrow"><i class="fa-solid fa-arrow-left"></i></button>
                        <button class="next-arrow"><i class="fa-solid fa-arrow-right"></i></button>
                    </div>
                </div>


                <div class="row row-gap-4">
                    <div class="col-lg-6  col-12">
                        <div class="product-sales-deel-area">
                            <h3 class="multi-heading-2  text-center top-0">Home</h3>
                            <h3 class="multi-heading-2 smart">Smart Bags</h3>
                            <div class="multi-content text-center multi-main-heading">
                                <h3 class="sys-hd">Upto 40% Off <br>
                                    Limited time deal grab today!</h3>
                                <p class="para">Lobortis scelerisque fermentum dui faucibus in. Dui nunc mattis enim
                                    ut tellus elementum. Neque <br> gravida in fermentum et. At urna condimentum mattis
                                    pellentesque id.</p>
                                <a href="#" class="anchor-btn">View Collections</a>
                            </div>
                            <img class="img-fluid img-pr" src="<?php echo e(asset('assets/web/images/img-pr.png')); ?>"
                                alt="">
                        </div>
                    </div>
                    <div class="col-lg-6 col-12 second-column-area">
                        <div class="mb-4">
                            <img class="img-fluid " src="<?php echo e(asset('assets/web/images/img-banner.png')); ?>"
                                alt="">
                        </div>
                        <div class="tip-area">
                            <h2 class="multi-heading-2 tip-bg">#6938</h2>
                            <span class="exc-products">TIP OF THE DAY</span>
                            <h3 class="sys-hd tip-hd">Keep your electronics safe: For long-
                                lasting performance, use surge
                                protectors and keep your software
                                updated.</h3>
                            <div class="pf-area">
                                <div>
                                    <img src="<?php echo e(asset('assets/web/images/pf-img.png')); ?>" alt="">
                                </div>
                                <div>
                                    <h4 class="pf-hd">Emilio Morse</h4>
                                    <p class="pf-para">Ceo of polonos</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="featured-products">
                    <div class="row mt-5">
                        <div class="col-12">
                            <div class="text-center">
                                <span class="exc-products">Shop Accessories</span>
                                <h2 class="main-sec-heading mt-4">
                                    Featured Products
                                </h2>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-5">

                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <a href="<?php echo e(route('products.show', ['id' => 1])); ?>" class="text-decoration-none">
                                <div class="feature-product-card">
                                    <div class="feature-product-img-area">
                                        <img class="img-fluid feature-product-img"
                                            src="<?php echo e(asset('assets/web/images/feature1.png')); ?>" alt="">
                                    </div>
                                    <div class="feature-product-details">
                                        <span class="category">
                                            Sale
                                        </span>
                                        <h3 class="card-main-heading">Black Hoodie’s</h3>
                                        <div class="rating-stars">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                        </div>
                                        <p class="price-products">$30.00 – $42.00</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <a href="<?php echo e(route('products.show', ['id' => 2])); ?>" class="text-decoration-none">
                                <div class="feature-product-card">
                                    <div class="feature-product-img-area">
                                        <img class="img-fluid feature-product-img"
                                            src="<?php echo e(asset('assets/web/images/feature1.png')); ?>" alt="">
                                    </div>
                                    <div class="feature-product-details">
                                        <span class="category">
                                            Sale
                                        </span>
                                        <h3 class="card-main-heading">Black Hoodie’s</h3>
                                        <div class="rating-stars">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                        </div>
                                        <p class="price-products">$30.00 – $42.00</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <a href="<?php echo e(route('products.show', ['id' => 3])); ?>" class="text-decoration-none">
                                <div class="feature-product-card">
                                    <div class="feature-product-img-area">
                                        <img class="img-fluid feature-product-img"
                                            src="<?php echo e(asset('assets/web/images/feature1.png')); ?>" alt="">
                                    </div>
                                    <div class="feature-product-details">
                                        <span class="category">
                                            Sale
                                        </span>
                                        <h3 class="card-main-heading">Black Hoodie’s</h3>
                                        <div class="rating-stars">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                        </div>
                                        <p class="price-products">$30.00 – $42.00</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <a href="<?php echo e(route('products.show', ['id' => 4])); ?>" class="text-decoration-none">
                                <div class="feature-product-card">
                                    <div class="feature-product-img-area">
                                        <img class="img-fluid feature-product-img"
                                            src="<?php echo e(asset('assets/web/images/feature1.png')); ?>" alt="">
                                    </div>
                                    <div class="feature-product-details">
                                        <span class="category">
                                            Sale
                                        </span>
                                        <h3 class="card-main-heading">Black Hoodie’s</h3>
                                        <div class="rating-stars">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                        </div>
                                        <p class="price-products">$30.00 – $42.00</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <a href="<?php echo e(route('products.show', ['id' => 5])); ?>" class="text-decoration-none">
                                <div class="feature-product-card">
                                    <div class="feature-product-img-area">
                                        <img class="img-fluid feature-product-img"
                                            src="<?php echo e(asset('assets/web/images/feature1.png')); ?>" alt="">
                                    </div>
                                    <div class="feature-product-details">
                                        <span class="category">
                                            Sale
                                        </span>
                                        <h3 class="card-main-heading">Black Hoodie’s</h3>
                                        <div class="rating-stars">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                        </div>
                                        <p class="price-products">$30.00 – $42.00</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <a href="<?php echo e(route('products.show', ['id' => 6])); ?>" class="text-decoration-none">
                                <div class="feature-product-card">
                                    <div class="feature-product-img-area">
                                        <img class="img-fluid feature-product-img"
                                            src="<?php echo e(asset('assets/web/images/feature1.png')); ?>" alt="">
                                    </div>
                                    <div class="feature-product-details">
                                        <span class="category">
                                            Sale
                                        </span>
                                        <h3 class="card-main-heading">Black Hoodie’s</h3>
                                        <div class="rating-stars">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                            <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="">
                                        </div>
                                        <p class="price-products">$30.00 – $42.00</p>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="super-sale-area">
                            <div class="super-sale-area-img">
                                <img src="<?php echo e(asset('assets/web/images/super.png')); ?>" alt="">
                                <p>On All Electronic Products, don’t miss this ! Use code :</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <section class="blog-section mx-3">
            <div class="container-fluid p-0">
                <div class="row align-items-center  mb-5">
                    <div class="col-lg-5 col-12 d-flex justify-content-center">
                        <div class="blog-hd-area" style="border-left: none">
                            <span class="exc-products">OUR BLOGS</span>
                            <h1 class="main-sec-heading mt-5">Latest News</h1>
                        </div>
                    </div>
                    <div class="col-lg-6 col-12 d-flex justify-content-center">
                        <div class="blog-hd-area">
                            <p class="para gray">Arcu vitae elementum curabitur vitae nunc sed. Non arcu
                                risus
                                quis <br>
                                varius. Elit eget gravida cum sociis magnis dis.</p>
                            <a href="<?php echo e(route('web.blogs.index')); ?>" class="link-btn">View All Blogs</a>
                        </div>
                    </div>
                </div>
                <hr class="blog-hr">
                <div class="row">
                    <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12 p-0">
                            <div class="blog-card">
                                <div class="blog-img-area">
                                    <img class="img-fluid blog-img" src="<?php echo e($blog->getFirstMediaUrl('blog_image')); ?>"
                                        alt="">
                                    <span class="img-banner"><?php echo e($blog->created_at); ?></span>
                                </div>
                                <div class="blog-text-area">
                                    <h3 class="card-main-heading"><?php echo e($blog->name); ?></h3>
                                    <p class="para gray"><?php echo e(\Str::limit($blog->short_description, 50, '...')); ?></p>
                                    <a href="<?php echo e(route('web.blogs.show', $blog->slug)); ?>" class="link-btn">Read More</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
                    
                </div>
            </div>

        </section>

        

        
    </main>


    <script>
        function countdownTimer() {
            const targetDate = new Date("2025-12-31T23:59:59").getTime();

            const interval = setInterval(() => {
                const now = new Date().getTime();
                const difference = targetDate - now;

                const days = Math.floor(difference / (1000 * 60 * 60 * 24));
                const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((difference % (1000 * 60)) / 1000);

                document.getElementById("days").textContent = days;
                document.getElementById("hours").textContent = hours;
                document.getElementById("minutes").textContent = minutes;
                document.getElementById("seconds").textContent = seconds;

                if (difference < 0) {
                    clearInterval(interval);
                    document.querySelector(".countdown").innerHTML = "Countdown Ended!";
                }
            }, 1000);
        }

        countdownTimer();
    </script>
    <script></script>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php if(session('not_logged_in')): ?>
        
        <script>
            Swal.fire({
                title: "Not Logged In!",
                text: "<?php echo e(session('not_logged_in')); ?>",
                icon: "warning",
                confirmButtonText: "OK"
            });
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.web.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Anjan Parmar\resources\views/screens/web/index.blade.php ENDPATH**/ ?>