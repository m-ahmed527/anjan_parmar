<header>
    <?php
        $cats = App\Models\Category::all();
        // dd($categories[0]->name);
    ?>
    <div class="header-top">
        <p class="header-top-para">20% On All Popular Products</p>
        <div class="lang-curren">
            <button class="btn-style small-btn" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal">
                <i class="fa fa-search"></i>
            </button>
            <a href="<?php echo e(route('web.vendor.register.view')); ?>" class="vendors-btn vendor-outline">
                Signup as vendors
            </a>
        </div>
    </div>
    <div class="header-second">
        <a href="<?php echo e(route('index')); ?>">
            <img src="<?php echo e(asset('assets/web/images/grey-logo.png')); ?>" class="logo img-fluid" alt="">
        </a>

        <div class="position-relative">
            <div class="search-header">
                <select name="category" id="" class="btn  anchor-btn text-start search-select">
                    <option value="">Choose Categories</option>
                    <?php $__empty_1 = true; $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value=<?php echo e($cat->slug); ?>><?php echo e($cat->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <option value="">No Category Available</option>
                    <?php endif; ?>

                </select>
                <input id="search" type="text" name="product_name" placeholder="Search Your Products"
                    class="header-search-input search-input">
            </div>

            <div class="search-suggestions">
                <ul class="search-suggestions--list hidden">
                    
                </ul>
            </div>
        </div>

        
        <ul class="nav-links-main">
            <li class="position-relative">
                <a href="<?php echo e(route('web.wishlist.index')); ?>"
                    class="btn-style heart-btn text-decoration-none wishlist-btn">
                    <i class="fa fa-heart"></i>
                </a>
                <span class="number-badge wishlist-count"><?php echo e(auth()?->user()?->wishlistCount() ?? 0); ?></span>
            </li>
            <li class="position-relative">
                <a href="<?php echo e(route('web.cart.index')); ?>" class="cart-price-area text-decoration-none cart-btn">
                    <span class="cart-icon-area">
                        <i class="fa-solid fa-cart-arrow-down"></i>
                    </span>
                    <span class="price-total cart-price">$<?php echo e(session('cart')['total'] ?? 00.0); ?></span>
                </a>
                <span class="number-badge cart-count"><?php echo e(session('cart')['total_items'] ?? 0); ?></span>
            </li>
            <li>
                <?php if(auth()->guard()->check()): ?>
                    <form action="<?php echo e(route('web.logout')); ?>" method="POST" id="logout-form">
                        <?php echo csrf_field(); ?>
                        <button type="button" class="btn btn-style user-btn" id="logout-btn">
                            <i class="fa-solid fa-right-from-bracket"></i>
                        </button>
                    </form>
                <?php else: ?>
                    <button type="button" class="btn btn-style user-btn" data-bs-toggle="modal" data-bs-target="#auth">
                        <i class="fa-regular fa-circle-user"></i>
                    </button>

                <?php endif; ?>
            </li>
            <li>
                <button class="btn-style search-btn-menu bar-btn">
                    <i class="fa-solid fa-bars"></i>
                </button>
            </li>
        </ul>
    </div>
    <nav class="header-third">
        <ul class="nav-links-main-2">
            <li>
                <a href="<?php echo e(route('index')); ?>" class="nav-link link-active">
                    Home
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('about-us')); ?>" class="nav-link">
                    About
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('web.categories.index')); ?>" class="nav-link">
                    Categories
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('web.products.index')); ?>" class="nav-link">
                    Products
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('web.stores.index')); ?>" class="nav-link">
                    Shop by store
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('web.blogs.index')); ?>" class="nav-link">
                    Blogs
                </a>
            </li>
        </ul>
        <?php if(auth()->guard()->guest()): ?>
            <a href="<?php echo e(route('web.vendor.register.view')); ?>" class="vendors-btn">
                Signup as vendors
            </a>
        <?php endif; ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
            <a href="<?php echo e(route('admin.index')); ?>" class="vendors-btn">
                Admin Dashboard
            </a>
        <?php endif; ?>
        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Vendor')): ?>
            <a href="<?php echo e(route('vendor.dashboard.index')); ?>" class="vendors-btn">
                Vendor Dashboard
            </a>
        <?php endif; ?>

    </nav>
    <div class="off-canva-custom">
        <div class="menu-bar">
            <div>
                <button class="search-btn-menu close-btn">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>
            <ul>
                <li>
                    <a href="<?php echo e(route('index')); ?>" class="nav-link">
                        Home
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('about-us')); ?>" class="nav-link">
                        About
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('web.categories.index')); ?>" class="nav-link">
                        Categories
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('web.products.index')); ?>" class="nav-link">
                        Products
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('shop')); ?>" class="nav-link">
                        Shop
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('web.blogs.index')); ?>" class="nav-link">
                        Blogs
                    </a>
                </li>
            </ul>
        </div>
    </div>


    <!-- Modal -->
    
    <div class="modal fade" id="auth" tabindex="-1" aria-labelledby="authModalLabel" aria-hidden="true">
        <div class="modal-dialog centered-modal">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <img src="<?php echo e(asset('assets/web/images/Seal-Offer-llc.png')); ?>" alt=""
                        class="logo img-fluid mb-5">
                </div>
                <div class="modal-body">
                    <div class="auth-buttons">
                        <a href="<?php echo e(route('web.register')); ?>" class="btn  w-100 mb-3">
                            Sign up
                        </a>
                        <a href="<?php echo e(route('web.login')); ?>" class="btn w-100">
                            Login
                        </a>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-danger" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>



</header>














<?php /**PATH C:\xampp\htdocs\Anjan Parmar\resources\views/includes/web/header.blade.php ENDPATH**/ ?>