<div id="showing-results" class="small text-muted d-none">
    Showing <span class="fw-semibold"><?php echo e($products->firstItem()); ?></span>
    to <span class="fw-semibold"><?php echo e($products->lastItem()); ?></span>
    of <span class="fw-semibold"><?php echo e($products->total()); ?></span> results
</div>

<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-xxl-4  col-md-6 col-sm-6 col-12 mb-3 column-grid-change">
        <div class="product-card sh-prod-card">
            <div class="products-img sh-prod">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <p class="top-img"><?php echo e($product->category->name); ?></p>
                    <button class="btn heart-save-btn p-0 wishlist-btn" data-slug="<?php echo e($product->slug); ?>">
                        <i class=" <?php echo e(auth()?->user()?->hasWishlisted($product->id) ? 'fa-solid' : 'fa-regular'); ?> fa-heart"
                            data-slug="icon-<?php echo e($product->slug); ?>" style="color: rgb(255, 114, 114)"></i>
                    </button>
                </div>
                <img src="<?php echo e($product->getFirstMediaUrl('featured_image')); ?>" class="img-fluid" alt="">
            </div>
            <div class="product-content">
                <h2 class="card-main-heading mb-4"><?php echo e($product->name); ?></h2>
                <div>
                    <div class="rating-stars mb-3">
                        <?php for($i = 0; $i < 5; $i++): ?>
                            <?php if($product['id'] > $i): ?>
                                <img src="<?php echo e(asset('assets/web/images/gold-star.png')); ?>" alt="Gold Star">
                            <?php else: ?>
                                <img src="<?php echo e(asset('assets/web/images/silver-star.png')); ?>" alt="Silver Star">
                            <?php endif; ?>
                        <?php endfor; ?>
                    </div>
                    <div class="bottom-price-area mb-3">
                        <p class="price-products">$<?php echo e($product->getMinPrice()); ?> - $<?php echo e($product->getMaxPrice()); ?></p>
                        <a href="<?php echo e(route('web.products.show', $product->slug)); ?>"
                            class="bid-btn text-decoration-none">Buy
                            Now</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-12">
        <div class="no-products">
            <h2 class="no-products-heading">No Products Found</h2>
            <p class="no-products-para">No products were found matching your selection.</p>
        </div>
    </div>
<?php endif; ?>

<div class="col-12 mt-5">
    <div class="pagination-btns">
        <?php echo e($products->appends(request()->query())->links('pagination::bootstrap-5')); ?>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Anjan Parmar\resources\views/screens/web/products/list.blade.php ENDPATH**/ ?>