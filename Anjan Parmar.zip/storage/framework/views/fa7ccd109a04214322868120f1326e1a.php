<?php $__env->startSection('content'); ?>
    <main>

        <div class="shop-banner-section">
            <div class="container-fluid px-4">
                <div class="shop-banner"
                    <?php if(request()->has('store')): ?> style="background-image: url('<?php echo e($store->getFirstMediaUrl('avatar')); ?>');" <?php endif; ?>>
                    <div>
                        <?php if(request()->has('store')): ?>
                            <h1 class="sh-head"><?php echo e($store->business_name); ?> Store</h1>
                            <p class="sh-para"><a href="<?php echo e(route('index')); ?>" class="text-decoration-none">Home</a>
                                / <a href="<?php echo e(route('web.stores.index')); ?>" class="text-decoration-none">Stores</a>
                                /<?php echo e($store->business_name); ?>

                            </p>
                        <?php else: ?>
                            <h1 class="sh-head">Products</h1>
                            <p class="sh-para"><a href="<?php echo e(route('index')); ?>" class="text-decoration-none">Home</a> /
                                Products
                        <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>

        </div>
        

        <div class="container-fluid my-5 sh-space">
            <div class="row g-4">
                <div class="col-xl-4 col-12 px-5 side-bar-area">
                    <div class="close-area-sidebar">
                        <button class="btn-close"><i class="fa-solid fa-xmark"></i></button>
                    </div>
                    <div class="content-sidebar">
                        <div class="filter-product-1 mb-4">
                            <div class="filter-header-1">
                                <h2 class="filter-heading">Categories</h2>
                            </div>
                            <div class="radio-list">
                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <label for="radio_<?php echo e($key); ?>">
                                        <input id="radio_<?php echo e($key); ?>" name="category" type="radio"
                                            value="<?php echo e($category->slug); ?>"
                                            <?php echo e($category->slug == request()->category ? 'checked' : ''); ?>>
                                        <span><?php echo e($category->name); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    No categories found!
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php
                            $minPrice = \App\Models\Product::min('price') ?? 0; // Agar null ho to 0
                            $maxPrice = \App\Models\Product::max('price') ?? 100; // Agar null ho to default 100
                            // dd($minPrice, $maxPrice);
                        ?>
                        <div class="filter-product-1 mb-4">
                            <div class="filter-header-1">
                                <h2 class="filter-heading">Prices</h2>
                            </div>
                            <div class="range-area">
                                <div class="slider-container">
                                    <input type="range" min="<?php echo e($minPrice); ?>" max="<?php echo e($maxPrice); ?>"
                                        value="<?php echo e($minPrice); ?>" id="minRange" class="slider min-slider">
                                    <input type="range" min="<?php echo e($minPrice); ?>" max="<?php echo e($maxPrice); ?>"
                                        value="<?php echo e($maxPrice); ?>" id="maxRange" class="slider max-slider">
                                </div>
                                <div class="range-values">
                                    <div class="style-amount">
                                        $<span id="minValue"><?php echo e($minPrice); ?></span>
                                    </div>
                                    <div class="style-amount">
                                        $<span id="maxValue"><?php echo e($maxPrice); ?></span>
                                    </div>
                                </div>
                                
                            </div>
                        </div>

                        <div class="mb-4">
                            <div class="range-area position-relative p-0 flex-row">
                                <img src="<?php echo e(asset('assets/web/images/sale-img.png')); ?>" class="img-fluid sale-img-product"
                                    alt="">
                                <a href="#" class="anchor-sale-product">View Collection</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-xl-8 col-12 px-4">
                    <div class="row custom-gx-space">
                        <div class="col-12">
                            <div class="right-col-row">
                                <div>
                                    <button class="btn-open-sidebar mb-2"><i class="fa-solid fa-arrow-right"></i></button>
                                    <h5 class="mb-3 showing-res" id="showing-results-container">
                                        
                                    </h5>
                                </div>
                                <div class="button-pr-group mb-3">
                                    <button class="btns-filter-open grid-active">
                                        <img src="<?php echo e(asset('assets/web/images/window-icon.png')); ?>" class="img-fluid"
                                            alt="">
                                    </button>
                                    <button class="btns-filter-open">
                                        <img src="<?php echo e(asset('assets/web/images/tab.png')); ?>" class="img-fluid"
                                            alt="">
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="row" id="product-container">
                            <?php echo $__env->make('screens.web.products.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                    </div>
                </div>
            </div>


        </div>
        </div>



        <?php if (isset($component)) { $__componentOriginalf53df0eb2e0eda3be514418670264723 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf53df0eb2e0eda3be514418670264723 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.slide-blog','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('slide-blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf53df0eb2e0eda3be514418670264723)): ?>
<?php $attributes = $__attributesOriginalf53df0eb2e0eda3be514418670264723; ?>
<?php unset($__attributesOriginalf53df0eb2e0eda3be514418670264723); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf53df0eb2e0eda3be514418670264723)): ?>
<?php $component = $__componentOriginalf53df0eb2e0eda3be514418670264723; ?>
<?php unset($__componentOriginalf53df0eb2e0eda3be514418670264723); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal35b0f49afff8dd7852c38ff684c207c2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal35b0f49afff8dd7852c38ff684c207c2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.our-blog','data' => ['blogs' => $blogs]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('our-blog'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['blogs' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($blogs)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal35b0f49afff8dd7852c38ff684c207c2)): ?>
<?php $attributes = $__attributesOriginal35b0f49afff8dd7852c38ff684c207c2; ?>
<?php unset($__attributesOriginal35b0f49afff8dd7852c38ff684c207c2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal35b0f49afff8dd7852c38ff684c207c2)): ?>
<?php $component = $__componentOriginal35b0f49afff8dd7852c38ff684c207c2; ?>
<?php unset($__componentOriginal35b0f49afff8dd7852c38ff684c207c2); ?>
<?php endif; ?>
    </main>


    <script>
        const btnsArea = document.querySelectorAll(".btns-filter-open");
        const column = document.querySelectorAll(".column-grid-change");
        const methodGrid = (grid) => {
            console.log(grid === "grid-half");
            column.forEach(element => {
                const productCards = element.querySelector(".product-card");
                const productImgArea = productCards.querySelector(".products-img");
                const productContent = productCards.querySelector(".product-content");
                const productBtnArea = productContent.querySelector(".bottom-price-area");
                if (grid === "grid-half") {
                    if (screen.width <= 991) {
                        element.classList.add("col-md-6");

                    } else {
                        element.classList.replace("col-xxl-6", "col-xxl-4");
                    }
                    productCards.classList.remove('grid-flex');
                    productImgArea.classList.remove("product-img-grid");
                    productContent.classList.remove("product-content-grid-area");
                    productBtnArea.classList.remove("btn-grid-change")
                } else {
                    if (screen.width <= 991) {
                        element.classList.remove("col-md-6");
                        element.classList.remove("col-sm-6");
                    } else {
                        element.classList.replace("col-xxl-4", "col-xxl-6");
                    }
                    productCards.classList.add('grid-flex');
                    productImgArea.classList.add("product-img-grid");
                    productContent.classList.add("product-content-grid-area");
                    productBtnArea.classList.add("btn-grid-change");
                    element.classList.remove("mb-4")
                }
            });
        }
        btnsArea[0].addEventListener('click', () => {
            methodGrid('grid-half');
            btnsArea[0].classList.add("grid-active");
            btnsArea[1].classList.remove("grid-active")
        })

        btnsArea[1].addEventListener('click', () => {
            methodGrid('grid-full');
            btnsArea[1].classList.add("grid-active");
            btnsArea[0].classList.remove("grid-active")
        })
    </script>
    <script>
        const btn = document.querySelectorAll(".pag-btn");

        const method = (element, btns) => {
            element.addEventListener("click", () => {
                btns.forEach(button => button.classList.remove("pagination-active"))
                element.classList.add("pagination-active");
            })
        }
        btn.forEach(element => {
            method(element, btn)
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make('includes.web.products.products-list-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.web.products.products-filter-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.web.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Anjan Parmar\resources\views/screens/web/products/index.blade.php ENDPATH**/ ?>