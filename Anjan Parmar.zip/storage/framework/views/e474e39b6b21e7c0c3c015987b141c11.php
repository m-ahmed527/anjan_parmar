<?php echo $__env->make('includes.web.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(
    !request()->route()->named('web.forgot.password') &&
        !request()->route()->named('web.reset.password') &&
        !request()->route()->named('web.register') &&
        !request()->route()->named('web.login') &&
        !request()->route()->named('web.vendor.register.view')): ?>
    <?php echo $__env->make('includes.web.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php echo $__env->yieldContent('content'); ?>

<?php if(
    !request()->route()->named('web.forgot.password') &&
        !request()->route()->named('web.reset.password') &&
        !request()->route()->named('web.register') &&
        !request()->route()->named('web.login') &&
        !request()->route()->named('web.vendor.register.view')): ?>
    <?php echo $__env->make('includes.web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\Anjan Parmar\resources\views/layouts/web/app.blade.php ENDPATH**/ ?>