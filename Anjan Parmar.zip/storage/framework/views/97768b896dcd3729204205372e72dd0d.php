<script>
    $(document).on('click', '.wishlist-btn', function(e) {
        e.preventDefault(); // Prevent default link behavior

        $.ajax({
            url: "<?php echo e(route('web.wishlist.index')); ?>",
            method: "GET",
            success: function(response) {
                console.log(response.success);

                // if (response.success) {
                window.location.href =
                    "<?php echo e(route('web.wishlist.index')); ?>"; // Open Wishlist if allowed
                // }
            },
            error: function(xhr) {
                if (xhr.status === 401 || xhr.status === 403) { // Unauthorized or Empty Wishlist
                    Swal.fire({
                        icon: "info",
                        title: xhr.responseJSON.message,
                        showConfirmButton: true
                    });
                }
            }
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\Anjan Parmar\resources\views/includes/web/header-scripts/wishlist-index-script.blade.php ENDPATH**/ ?>