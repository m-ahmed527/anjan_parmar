<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Services\CartService\CartServiceProvider::class
];
